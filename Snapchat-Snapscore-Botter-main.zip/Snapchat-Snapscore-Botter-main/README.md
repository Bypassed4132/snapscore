<br/>
<div align="center">
  
  # Snapchat Snapscore Botter
  
<h1>
🌟 Join my Discord server <a href="https://discord.gg/rDGsC2rwVv">here</a> 🌟
</h1>
  
  Python-based Snapchat score booster using pyautogui module. Click <a href="https://github.com/useragents/Snapchat-Snapscore-Botter/issues">here</a> to report bugs.
  
  ![image](https://user-images.githubusercontent.com/103281345/162591882-3a211ead-0f10-4ba1-bdcc-8f2186294377.png)


  
</div>

--------------------------------------

### Usage


1. Download ZIP <a href="https://github.com/useragents/Snapchat-Snapscore-Botter/archive/refs/heads/main.zip">here</a> and extract the ZIP
2. Install <a href="https://github.com/useragents/Snapchat-Snapscore-Botter/blob/main/requirements.txt">requirements.txt</a> by typing `pip install -r requirements.txt` in Command Prompt
3. Download an android emulator like <a href="https://www.bluestacks.com/">BlueStacks</a>, <a href="https://www.memuplay.com/">Memu</a>, <a href="https://www.bignox.com/">Nox</a>, etc
4. Download the Snapchat app on the emulator and login to your account
5. Create a shortcut with a list of users that you want to send snaps to
6. Run the `main.py` script and follow the instructions shown. Confused? Watch the tutorial video <a href="https://www.youtube.com/watch?v=-ZVj913gJ_k">here</a>

### Please note

This script was made for educational purposes, I am not responsible for your actions using this script.
This script works best when you are not using your PC as it moves your mouse position around the emulator to send snaps.
Watch the tutorial video <a href="https://www.youtube.com/watch?v=-ZVj913gJ_k">here</a> if you are confused on what to do.
